<div class="home-search-wrap">
    <div class="default-form-wrap">
        <div class="single-input-wrap">
            <label><img src="{{asset('assets/img/icon/search.svg')}}" alt="img"></label>
            <input type="text" class="form-control" placeholder="Procure por um Produto">
        </div>
    </div>
</div>
