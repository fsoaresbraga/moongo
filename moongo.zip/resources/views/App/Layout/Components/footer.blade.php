<div class="main-footer-bottom d-block text-center">
    <ul>
        <li>
            <a href="#">
                <img src="{{asset('assets/img/icon/svg/home.svg"')}} alt="icon">
            </a>
        </li>
        <li>
            <a href="#">
                <img src="{{asset('assets/img/icon/svg/search.svg')}}" alt="img">
            </a>
        </li>
        <li class="shop-btn">
            <a class="menu-bar" href="#">
                <img src="{{asset('assets/img/icon/svg/bag.svg')}}" alt="img">
            </a>
        </li>
        <li>
            <a href="#">
                <img src="{{asset('assets/img/icon/svg/discount.svg')}}" alt="img">
            </a>
        </li>
        <li>
            <a href="#">
                <img src="{{asset('assets/img/icon/svg/profile.svg')}}" alt="img">
            </a>
        </li>
    </ul>
</div>
