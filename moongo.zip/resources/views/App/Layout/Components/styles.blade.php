@php
    //core.css
    /*
<link rel="stylesheet" href="{{asset('assets/css/bootstrap.min.css')}}">
<link rel="stylesheet" href="{{asset('assets/css/magnific.min.css')}}">
<link rel="stylesheet" href="{{asset('assets/css/jquery-ui.min.css')}}">
<link rel="stylesheet" href="{{asset('assets/css/fontawesome.min.css')}}">
<link rel="stylesheet" href="{{asset('assets/css/magnific.min.css')}}">
<link rel="stylesheet" href="{{asset('assets/css/style.css')}}">
<link rel="stylesheet" href="{{asset('assets/css/responsive.css')}}">
<link rel="stylesheet" href="{{asset('assets/css/sweetalert2.css')}}">
*/
@endphp

<link rel="stylesheet" href="{{asset('passenger/css/core.css')}}">



