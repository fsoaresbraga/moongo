
@php
/*
    <script src="{{asset('assets/js/jquery.3.6.min.js')}}"></script>
    <script src="{{asset('assets/js/bootstrap.min.js')}}"></script>
    <script src="{{asset('assets/js/jquery-ui.min.js')}}"></script>
    <script src="{{asset('assets/js/sweetalert2.all.js')}}"></script>
    <script src="https://cdn.jsdelivr.net/gh/MoralistFestus/ClipLab/src/cliplab.min.js"></script>
    <script src="{{asset('assets/js/functions.js')}}"></script>
    <script src="{{asset('assets/js/main.js')}}"></script>
    <script src="{{asset('assets/js/products.js')}}"></script>
    <script src="{{asset('assets/js/cart.js')}}"></script>
    <script src="{{asset('assets/js/checkout.js')}}"></script>
*/
@endphp

<script src="{{asset('passenger/js/core.js')}}"></script>