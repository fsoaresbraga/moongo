<footer class="footer">
    <div class="d-sm-flex justify-content-center justify-content-sm-between">
      <span class="text-muted d-block text-center text-sm-left d-sm-inline-block">Copyright © Moongo.com.br {{\Carbon\Carbon::now()->format('Y')}}</span>
    </div>
  </footer>