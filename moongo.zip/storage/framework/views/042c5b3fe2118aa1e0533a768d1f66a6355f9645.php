<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <?php echo $__env->make('Admin.Layout.Components.styles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <link rel="shortcut icon" href="assets/images/favicon.png" />

    <script>
        window.onload = function() {
            $('.loader').fadeOut();
        }
    </script>
  </head>
<?php /**PATH C:\www\moongo\resources\views/Admin/Layout/Components/head.blade.php ENDPATH**/ ?>