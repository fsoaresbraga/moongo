<link rel="stylesheet" href="<?php echo e(asset('admin/vendors/mdi/css/materialdesignicons.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('admin/vendors/css/vendor.bundle.base.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('admin/vendors/jvectormap/jquery-jvectormap.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('admin/vendors/flag-icon-css/css/flag-icon.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('admin/vendors/owl-carousel-2/owl.carousel.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('admin/vendors/owl-carousel-2/owl.theme.default.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('admin/vendors/notification/notification.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('admin/vendors/sweetalert2/sweetalert2.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('admin/vendors/datatables/jquery.dataTables.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('admin/vendors/select2/select2.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('admin/css/style.css')); ?>">

<?php /**PATH C:\www\moongo\resources\views/Admin/Layout/Components/styles.blade.php ENDPATH**/ ?>