<!DOCTYPE html>
<html lang="pt_br">
    <?php echo $__env->make('Admin.Layout.Components.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <body>
    <div class="loader" ><img src="<?php echo e(asset('admin/assets/images/loading.gif')); ?>"></div>
    <div class="container-scroller">

      <?php echo $__env->make('Admin.Layout.Components.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

      <div class="container-fluid page-body-wrapper">

        <?php echo $__env->make('Admin.Layout.Components.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="main-panel">

            <?php echo $__env->yieldContent('content'); ?>

           <?php echo $__env->make('Admin.Layout.Components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
      </div>
    </div>
    <?php echo $__env->make('Admin.Layout.Components.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <script>
        <?php if(Session::has('message')): ?>
            $.growl({
                icon: " <?php echo e(Session::get('icon')); ?> ",
                title: " <?php echo e(Session::get('title')); ?> ",
                message: " <?php echo e(Session::get('message')); ?> ",
                url: ''
            },{
                element: 'body',
                type: "<?php echo e(Session::get('type')); ?>",
                allow_dismiss: true,
                placement: {
                    from: 'top',
                    align: 'right'
                },
                offset: {
                    x: 30,
                    y: 30
                },
                spacing: 10,
                z_index: 999999,
                delay: 3000,
                timer: 1000,
                url_target: '_blank',
                mouse_over: false,
                animate: {
                    enter: 'animated bounceInRight',
                    exit: 'animated bounceOutRight'
                },
                icon_type: 'class',
                template: '<div data-growl="container" class="alert" style="width:470px" role="alert">' +
                '<span style="font-weight: bold;font-size:16px"data-growl="icon"></span>' +
                '<span style="font-weight: bold;font-size:14px" data-growl="title"></span><br />' +
                '<span style="font-weight: bold;font-size:16px" data-growl="message"></span>' +
                '<a href="#" data-growl="url"></a>' +
                '</div>'
            });
        <?php endif; ?>
    </script>
  </body>
</html>
<?php /**PATH C:\www\moongo\resources\views/Admin/Layout/app.blade.php ENDPATH**/ ?>